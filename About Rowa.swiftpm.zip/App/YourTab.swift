import SwiftUI

struct YourTab: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct YourTab_Previews: PreviewProvider {
    static var previews: some View {
        YourTab()
    }
}
